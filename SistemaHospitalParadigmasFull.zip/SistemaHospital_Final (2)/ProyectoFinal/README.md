# Sistema Hospital — Proyecto Final
**Paradigmas de Programación · .NET 8 / C#**

---

## Descripción del Sistema

Aplicación de consola para gestión hospitalaria que integra cuatro paradigmas de programación: **Orientado a Objetos**, **Funcional**, **Orientado a Aspectos** y **Orientado a Eventos**, respetando los principios **SOLID** a lo largo de todo el código.

---

## Decisiones de Diseño por Paradigma

### 1. Programación Orientada a Objetos (POO)
- `Persona` es la clase base de `Doctor` y `Paciente` (herencia).
- `Paciente` tiene composición con `HistorialMedico`.
- `HospitalizacionRepository` implementa la interfaz `IAsignacionHabitacion`.
- `DoctorServicio` implementa `IDoctorServicio`.
- Polimorfismo demostrable a través de las interfaces.

### 2. Programación Funcional (PF)
- **LINQ** en todos los repositorios y UIs: `Where`, `Select`, `Append`, `FirstOrDefault`, `Any`, `Aggregate`, `DefaultIfEmpty`, `Max`, `Concat`, `TakeWhile`.
- **Records inmutables** para los `EventArgs` (`PacienteFallecidoEventArgs`, `PacienteDadoDeAltaEventArgs`): una vez creados, sus datos no mutan.
- **Funciones puras**: `LicenciaEsValida`, `SplitLista`, proyecciones LINQ.
- **`IReadOnlySet`** para el conjunto de licencias válidas: no mutable en runtime.
- Se evita mutar colecciones existentes; se produce nuevas con `Append(...).ToList()` y `Where(...).ToList()`.

### 3. Programación Orientada a Aspectos (POA)
- **Librería**: `Castle.Core` (Castle.DynamicProxy).
- **Dos interceptores** (inquietudes transversales):
  - `LoggingInterceptor`: registra entrada/salida de todos los métodos del servicio.
  - `AuthenticacionDoctorInterceptor`: verifica que la licencia médica sea válida antes de permitir `RegistrarDoctor`. Si la licencia no existe en el conjunto de licencias válidas, lanza `UnauthorizedAccessException` y el método real nunca se ejecuta.
- **`ProxyFactory`**: crea el proxy dinámico tejiendo los interceptores sobre `DoctorServicio` en tiempo de ejecución, sin modificar la clase original.
- **Conceptos aplicados**: Aspecto, Consejo, Punto de unión, Punto de corte, Emisor/Proxy.

**Licencias válidas de prueba**: `10001, 10002, 10003, 20001, 20002, 30001, 99999`

### 4. Programación Orientada a Eventos (POE)
- `Paciente` es el **Emisor** de dos eventos personalizados:
  - `Fallecido` (con `PacienteFallecidoEventArgs`)
  - `DadoDeAlta` (con `PacienteDadoDeAltaEventArgs`)
- Los **Oyentes** están en `PacienteEventHandlers` (métodos estáticos suscritos con `+=`).
- El Paciente no sabe quién lo escucha; simplemente dispara el evento (bajo acoplamiento).
- Los eventos se disparan desde:
  - `UIPaciente` → opción "Registrar fallecimiento" y "Dar de alta paciente"
  - `UIHospitalizacion` → opción "Dar de alta"

---

## Principios SOLID

| Principio | Aplicación |
|-----------|-----------|
| **SRP** | `DoctorServicio` solo gestiona doctores; los interceptores manejan logging y auth |
| **OCP** | Nuevos aspectos = nuevo interceptor en `ProxyFactory`, sin tocar `DoctorServicio` |
| **LSP** | `Doctor` y `Paciente` sustituyen a `Persona` sin romper contratos |
| **ISP** | `IDoctorServicio` e `IAsignacionHabitacion` son interfaces pequeñas y específicas |
| **DIP** | `UIDoctor` depende de `IDoctorServicio`, no de `DoctorServicio` directamente |

---

## Estructura del Proyecto

```
SistemaHospital.csproj
├── ConsoleApp/
│   ├── Program.cs
│   ├── UIDoctor.cs          ← usa proxy AOP
│   ├── UIPaciente.cs        ← dispara eventos Fallecido y DadoDeAlta
│   ├── UIHospitalizacion.cs ← dispara evento DadoDeAlta
│   ├── UICita.cs
│   └── UIHistorial.cs
└── SistemaHospital/
    ├── Models/              ← Paciente (emisor de eventos), Doctor, Cita...
    ├── Interfaces/          ← IDoctorServicio, IAsignacionHabitacion
    ├── Eventos/             ← PacienteEventArgs (records), PacienteEventHandlers
    ├── Aspectos/            ← AuthenticacionDoctorInterceptor, LoggingInterceptor,
    │                            DoctorServicio, ProxyFactory
    └── Repositories/        ← CsvRepository<T>, repos concretos
```

---

## Cómo ejecutar

```bash
dotnet run
```

Los archivos CSV se generan automáticamente en el directorio de ejecución.
