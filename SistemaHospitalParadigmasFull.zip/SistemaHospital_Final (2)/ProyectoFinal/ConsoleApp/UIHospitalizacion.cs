using System;
using System.Linq;
using SistemaHospital.Eventos;
using SistemaHospital.Models;
using SistemaHospital.Repositories;

namespace AppConsole
{
    internal static class UIHospitalizacion
    {
        private static readonly HospitalizacionRepository _repo = new();
        private static readonly PacienteHistorialRepository _repoPacientes = new();

        // ── CRUD ─────────────────────────────────────────────────────────────

        private static void Crear()
        {
            var hospitalizaciones = _repo.CargarTodos();

            Console.WriteLine("Seleccione el paciente a hospitalizar:");
            var paciente = UIPaciente.Seleccionar();
            if (paciente == null) { Console.WriteLine("Operacion cancelada."); return; }

            Console.WriteLine("Seleccione el doctor supervisor:");
            var doctor = UIDoctor.Seleccionar();
            if (doctor == null) { Console.WriteLine("Operacion cancelada."); return; }

            // LINQ: ObtenerHabitacionDisponible usa Where + FirstOrDefault internamente
            int habitacionLibre = _repo.ObtenerHabitacionDisponible();
            if (habitacionLibre == -1) { Console.WriteLine("No hay habitaciones disponibles."); return; }

            // LINQ: Select + DefaultIfEmpty + Max para el siguiente ID sin romper en lista vacía
            int nuevoId = hospitalizaciones.Select(h => h.Id).DefaultIfEmpty(0).Max() + 1;

            var hosp = new Hospitalizacion(nuevoId, paciente.Identificacion, doctor.Identificacion, habitacionLibre, DateTime.Now);
            // LINQ: Append + ToList reemplaza .Add()
            _repo.GuardarTodos(hospitalizaciones.Append(hosp).ToList());

            Console.WriteLine($"Paciente '{paciente.Nombre}' hospitalizado en habitacion {habitacionLibre} bajo supervision de {doctor.Nombre}.");
        }

        private static void Listar()
        {
            var hs = _repo.CargarTodos();
            if (!hs.Any()) { Console.WriteLine("No hay hospitalizaciones registradas."); return; }

            Console.WriteLine("\n--- Hospitalizaciones ---");
            // LINQ: Select con índice proyecta cada hospitalización a su línea formateada
            hs
                .Select((h, i) =>
                {
                    var estado = h.EstaActiva ? "Activa" : $"Alta: {h.FechaAlta:d}";
                    return $"[{i}] ID:{h.Id} | Pac ID:{h.IdPaciente} | Dr ID:{h.IdDoctor} | Hab:{h.NumeroHabitacion} | Ingreso:{h.FechaIngreso:d} | {estado}";
                })
                .ToList()
                .ForEach(Console.WriteLine);
        }

        /// <summary>
        /// Da de alta desde Hospitalizaciones: actualiza el registro y dispara el
        /// evento PacienteDadoDeAlta sobre el Paciente correspondiente.
        /// Paradigma de Eventos: el Paciente (Emisor) notifica a sus Oyentes.
        /// </summary>
        private static void DarDeAlta()
        {
            var hs = _repo.CargarTodos();
            Listar();
            if (!hs.Any()) return;

            Console.Write("Indice de la hospitalizacion a dar de alta: ");
            if (!int.TryParse(Console.ReadLine(), out var idx) || idx < 0 || idx >= hs.Count)
            { Console.WriteLine("Indice invalido."); return; }

            if (!hs[idx].EstaActiva)
            { Console.WriteLine("Esa hospitalizacion ya tiene alta registrada."); return; }

            Console.Write("Observaciones de alta (Enter para omitir): ");
            var obs = Console.ReadLine() ?? "";

            // Actualizar la hospitalización
            hs[idx].DarDeAlta(DateTime.Now);
            _repo.GuardarTodos(hs);

            // Disparar evento sobre el Paciente (Emisor)
            var pacientes = _repoPacientes.CargarTodos();
            var paciente  = pacientes.FirstOrDefault(p => p.Identificacion == hs[idx].IdPaciente);

            if (paciente != null)
            {
                // Suscribimos el Oyente y disparamos el evento
                paciente.DadoDeAlta += PacienteEventHandlers.OnPacienteDadoDeAlta;
                paciente.RegistrarAlta(hs[idx].FechaAlta!.Value, obs);
            }
            else
            {
                Console.WriteLine("Alta registrada correctamente.");
            }
        }

        private static void Eliminar()
        {
            var hs = _repo.CargarTodos();
            Listar();
            if (!hs.Any()) return;

            Console.Write("Indice a eliminar: ");
            if (!int.TryParse(Console.ReadLine(), out var idx) || idx < 0 || idx >= hs.Count)
            { Console.WriteLine("Indice invalido."); return; }

            // LINQ: Where con índice reconstruye la lista sin el elemento; reemplaza RemoveAt
            _repo.GuardarTodos(hs.Where((_, i) => i != idx).ToList());
            Console.WriteLine("Hospitalizacion eliminada.");
        }

        public static void Gestionar()
        {
            const string menu = """

                --- Gestion de Hospitalizaciones ---
                1. Hospitalizar paciente
                2. Listar hospitalizaciones
                3. Dar de alta           [EVENTO]
                4. Eliminar hospitalizacion
                5. Volver
                Opcion: 
                """;

            do
            {
                Console.Write(menu);
                switch (Console.ReadLine())
                {
                    case "1": Crear();     break;
                    case "2": Listar();    break;
                    case "3": DarDeAlta(); break;
                    case "4": Eliminar();  break;
                    case "5": return;
                    default: Console.WriteLine("Opcion invalida."); break;
                }
            } while (true);
        }
    }
}
