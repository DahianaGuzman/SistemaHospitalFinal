using System;
using System.Linq;
using SistemaHospital.Models;
using SistemaHospital.Repositories;

namespace AppConsole
{
    internal static class UICita
    {
        private static readonly CitaRepository _repo = new();

        // ── CRUD ─────────────────────────────────────────────────────────────

        private static void Crear()
        {
            Console.WriteLine("Seleccione el paciente para la cita:");
            var paciente = UIPaciente.Seleccionar();
            if (paciente == null) { Console.WriteLine("Operacion cancelada."); return; }

            Console.WriteLine("Seleccione el doctor para la cita:");
            var doctor = UIDoctor.Seleccionar();
            if (doctor == null) { Console.WriteLine("Operacion cancelada."); return; }

            Console.Write("Fecha y hora (yyyy-MM-dd HH:mm): ");
            var fecha = DateTime.TryParse(Console.ReadLine(), out var f) ? f : DateTime.Now;

            Console.Write("Motivo de la cita: ");
            var motivo = Console.ReadLine() ?? "";

            var citas = _repo.CargarTodos();
            // LINQ: Select + DefaultIfEmpty + Max para obtener el siguiente ID sin romper en lista vacía
            int nuevoId = citas.Select(c => c.Id).DefaultIfEmpty(0).Max() + 1;

            var nueva = new Cita(nuevoId, fecha, paciente.Identificacion, doctor.Identificacion, motivo);
            // LINQ: Append agrega el elemento y ToList materializa; reemplaza .Add()
            _repo.GuardarTodos(citas.Append(nueva).ToList());
            Console.WriteLine($"Cita #{nuevoId} registrada: {paciente.Nombre} con {doctor.Nombre} el {fecha:g}.");
        }

        private static void Listar()
        {
            var citas = _repo.CargarTodos();
            if (!citas.Any()) { Console.WriteLine("No hay citas registradas."); return; }

            Console.WriteLine("\n--- Citas ---");
            // LINQ: Select con índice proyecta cada cita a su línea formateada
            citas
                .Select((c, i) => $"[{i}] ID:{c.Id} | {c.FechaCita:g} | Paciente ID:{c.IdPaciente} | Doctor ID:{c.IdDoctor} | Motivo: {c.Motivo}")
                .ToList()
                .ForEach(Console.WriteLine);
        }

        private static void Actualizar()
        {
            var citas = _repo.CargarTodos();
            Listar();
            if (!citas.Any()) return;

            Console.Write("Indice a actualizar: ");
            if (!int.TryParse(Console.ReadLine(), out var idx) || idx < 0 || idx >= citas.Count)
            { Console.WriteLine("Indice invalido."); return; }

            var c = citas[idx];
            Console.WriteLine("Deje vacio para mantener el valor actual.");

            Console.Write($"Nueva fecha ({c.FechaCita:g}): ");
            var texto = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(texto) && DateTime.TryParse(texto, out var fd)) c.FechaCita = fd;

            Console.Write($"Nuevo motivo ({c.Motivo}): ");
            var motivo = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(motivo)) c.Motivo = motivo;

            _repo.GuardarTodos(citas);
            Console.WriteLine("Cita actualizada.");
        }

        private static void Eliminar()
        {
            var citas = _repo.CargarTodos();
            Listar();
            if (!citas.Any()) return;

            Console.Write("Indice a eliminar: ");
            if (!int.TryParse(Console.ReadLine(), out var idx) || idx < 0 || idx >= citas.Count)
            { Console.WriteLine("Indice invalido."); return; }

            // LINQ: Where con índice reconstruye la lista sin el elemento; reemplaza RemoveAt
            _repo.GuardarTodos(citas.Where((_, i) => i != idx).ToList());
            Console.WriteLine("Cita eliminada.");
        }

        public static void Gestionar()
        {
            const string menu = """

                --- Gestion de Citas ---
                1. Crear cita
                2. Listar citas
                3. Actualizar cita
                4. Eliminar cita
                5. Volver
                Opcion: 
                """;

            do
            {
                Console.Write(menu);
                switch (Console.ReadLine())
                {
                    case "1": Crear();     break;
                    case "2": Listar();    break;
                    case "3": Actualizar(); break;
                    case "4": Eliminar();  break;
                    case "5": return;
                    default: Console.WriteLine("Opcion invalida."); break;
                }
            } while (true);
        }
    }
}
