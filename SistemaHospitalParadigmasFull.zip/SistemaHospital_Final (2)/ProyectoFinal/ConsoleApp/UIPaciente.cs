using System;
using System.Linq;
using SistemaHospital.Eventos;
using SistemaHospital.Models;
using SistemaHospital.Repositories;

namespace AppConsole
{
    // ─────────────────────────────────────────────────────────────────────────
    //  UIPaciente — capa de presentación para gestión de pacientes.
    //
    //  Paradigma de Eventos: suscribe los Oyentes (Listeners) a los eventos
    //  PacienteFallecido y PacienteDadoDeAlta del objeto Paciente antes de
    //  operar sobre él. El Paciente (Emisor) no sabe quién escucha.
    // ─────────────────────────────────────────────────────────────────────────
    internal static class UIPaciente
    {
        private static readonly PacienteHistorialRepository _repo = new();

        // ── Suscripción de eventos ────────────────────────────────────────────
        /// Suscribe los Manejadores de Evento al Paciente (paradigma de eventos).
        private static void SuscribirEventos(Paciente paciente)
        {
            paciente.Fallecido  += PacienteEventHandlers.OnPacienteFallecido;
            paciente.DadoDeAlta += PacienteEventHandlers.OnPacienteDadoDeAlta;
        }

        // ── CRUD ─────────────────────────────────────────────────────────────

        private static void Crear()
        {
            var p = LeerDesdConsola();
            // LINQ: Append agrega el nuevo elemento y ToList materializa la nueva lista
            _repo.GuardarTodos(_repo.CargarTodos().Append(p).ToList());
            Console.WriteLine($"Paciente '{p.Nombre}' creado correctamente.");
        }

        private static void Listar()
        {
            var pacientes = _repo.CargarTodos();
            if (!pacientes.Any()) { Console.WriteLine("No hay pacientes registrados."); return; }

            Console.WriteLine("\n--- Pacientes ---");
            // LINQ: Select con índice genera la línea formateada de cada paciente
            pacientes
                .Select((p, i) => $"[{i}] {p.Nombre} — ID: {p.Identificacion} | Edad: {p.Edad} | Tel: {p.Telefono} | Ingreso: {p.FechaIngreso:d}")
                .ToList()
                .ForEach(Console.WriteLine);
        }

        private static void Actualizar()
        {
            var pacientes = _repo.CargarTodos();
            Listar();
            if (!pacientes.Any()) return;

            Console.Write("Indice a actualizar: ");
            if (!int.TryParse(Console.ReadLine(), out var idx) || idx < 0 || idx >= pacientes.Count)
            { Console.WriteLine("Indice invalido."); return; }

            var p = pacientes[idx];
            Console.WriteLine("Deje vacio para mantener el valor actual.");

            Console.Write($"Nombre ({p.Nombre}): ");
            var nombre = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(nombre)) p.Nombre = nombre;

            Console.Write($"Edad ({p.Edad}): ");
            if (int.TryParse(Console.ReadLine(), out var edad)) p.Edad = edad;

            Console.Write($"Telefono ({p.Telefono}): ");
            if (int.TryParse(Console.ReadLine(), out var tel)) p.Telefono = tel;

            _repo.GuardarTodos(pacientes);
            Console.WriteLine("Paciente actualizado.");
        }

        private static void Eliminar()
        {
            var pacientes = _repo.CargarTodos();
            Listar();
            if (!pacientes.Any()) return;

            Console.Write("Indice a eliminar: ");
            if (!int.TryParse(Console.ReadLine(), out var idx) || idx < 0 || idx >= pacientes.Count)
            { Console.WriteLine("Indice invalido."); return; }

            var nombre = pacientes[idx].Nombre;
            // LINQ: Where con índice filtra el elemento a eliminar; reemplaza RemoveAt
            _repo.GuardarTodos(pacientes.Where((_, i) => i != idx).ToList());
            Console.WriteLine($"Paciente '{nombre}' eliminado.");
        }

        private static void GestionarHistorial()
        {
            var pacientes = _repo.CargarTodos();
            Listar();
            if (!pacientes.Any()) return;

            Console.Write("Indice del paciente: ");
            if (!int.TryParse(Console.ReadLine(), out var idx) || idx < 0 || idx >= pacientes.Count)
            { Console.WriteLine("Indice invalido."); return; }

            var p = pacientes[idx];
            UIHistorial.Gestionar(p.Historial);
            _repo.GuardarTodos(pacientes);
        }

        // ── Eventos de dominio ────────────────────────────────────────────────

        /// <summary>
        /// Registra el fallecimiento de un paciente y dispara el evento Fallecido.
        /// Paradigma de Eventos: el Paciente es el Emisor; los Oyentes reaccionan.
        /// </summary>
        private static void RegistrarFallecimiento()
        {
            var pacientes = _repo.CargarTodos();
            Listar();
            if (!pacientes.Any()) return;

            Console.Write("Indice del paciente fallecido: ");
            if (!int.TryParse(Console.ReadLine(), out var idx) || idx < 0 || idx >= pacientes.Count)
            { Console.WriteLine("Indice invalido."); return; }

            Console.Write("Causa del fallecimiento: ");
            var causa = Console.ReadLine() ?? "No especificada";

            var paciente = pacientes[idx];

            // Suscribimos el Oyente justo antes de disparar el evento
            SuscribirEventos(paciente);

            // El Emisor (Paciente) dispara el evento; el Oyente imprime la notificación
            paciente.RegistrarFallecimiento(causa);

            // Eliminamos al paciente del sistema después del fallecimiento
            _repo.GuardarTodos(pacientes.Where((_, i) => i != idx).ToList());
        }

        /// <summary>
        /// Da de alta a un paciente desde el menú de pacientes y dispara el evento.
        /// </summary>
        private static void DarDeAltaPaciente()
        {
            var pacientes = _repo.CargarTodos();
            Listar();
            if (!pacientes.Any()) return;

            Console.Write("Indice del paciente a dar de alta: ");
            if (!int.TryParse(Console.ReadLine(), out var idx) || idx < 0 || idx >= pacientes.Count)
            { Console.WriteLine("Indice invalido."); return; }

            Console.Write("Observaciones de alta (Enter para omitir): ");
            var obs = Console.ReadLine() ?? "";

            var paciente = pacientes[idx];

            // Suscribimos el Oyente antes de disparar
            SuscribirEventos(paciente);

            // El Emisor dispara el evento PacienteDadoDeAlta
            paciente.RegistrarAlta(DateTime.Now, obs);

            _repo.GuardarTodos(pacientes);
        }

        // ── Selección reutilizable ────────────────────────────────────────────

        public static Paciente? Seleccionar()
        {
            var pacientes = _repo.CargarTodos();

            if (pacientes.Any())
            {
                Console.WriteLine("\nPacientes disponibles:");
                pacientes
                    .Select((p, i) => $"[{i}] {p}")
                    .ToList()
                    .ForEach(Console.WriteLine);

                Console.Write("Indice ('n' = crear nuevo): ");
                var sel = Console.ReadLine();
                if (!string.IsNullOrWhiteSpace(sel) && sel.ToLower() != "n"
                    && int.TryParse(sel, out var idx) && idx >= 0 && idx < pacientes.Count)
                    return pacientes[idx];
            }

            var nuevo = LeerDesdConsola();
            // LINQ: Append + ToList reemplaza Add
            _repo.GuardarTodos(pacientes.Append(nuevo).ToList());
            return nuevo;
        }

        public static Paciente LeerDesdConsola()
        {
            Console.Write("Identificacion (numero): ");
            int id = int.TryParse(Console.ReadLine(), out var tmpId) ? tmpId : 0;

            Console.Write("Nombre: ");
            string nombre = Console.ReadLine() ?? "";

            Console.Write("Edad: ");
            int edad = int.TryParse(Console.ReadLine(), out var tmpE) ? tmpE : 0;

            Console.Write("Telefono: ");
            int tel = int.TryParse(Console.ReadLine(), out var tmpT) ? tmpT : 0;

            Console.Write("Fecha de ingreso (yyyy-MM-dd) [Enter = hoy]: ");
            var fi = Console.ReadLine();
            var fecha = DateTime.TryParse(fi, out var f) ? f : DateTime.Now;

            return new Paciente(id, nombre, edad, tel, fecha);
        }

        public static void Gestionar()
        {
            const string menu = """

                --- Gestion de Pacientes ---
                1. Crear paciente
                2. Listar pacientes
                3. Actualizar paciente
                4. Eliminar paciente
                5. Gestionar historial medico
                6. Registrar fallecimiento  [EVENTO]
                7. Dar de alta paciente     [EVENTO]
                8. Volver
                Opcion: 
                """;

            do
            {
                Console.Write(menu);
                switch (Console.ReadLine())
                {
                    case "1": Crear();                break;
                    case "2": Listar();               break;
                    case "3": Actualizar();           break;
                    case "4": Eliminar();             break;
                    case "5": GestionarHistorial();   break;
                    case "6": RegistrarFallecimiento(); break;
                    case "7": DarDeAltaPaciente();    break;
                    case "8": return;
                    default: Console.WriteLine("Opcion invalida."); break;
                }
            } while (true);
        }
    }
}
