using System;
using System.Collections.Generic;
using System.Linq;
using SistemaHospital.Models;

namespace AppConsole
{
    internal static class UIHistorial
    {
        public static void Gestionar(HistorialMedico historial)
        {
            const string menu = """

                --- Historial Medico ---
                1. Ver historial
                2. Agregar diagnostico
                3. Agregar tratamiento
                4. Agregar observacion
                5. Limpiar historial
                6. Volver
                Opcion: 
                """;

            while (true)
            {
                Console.Write(menu);
                switch (Console.ReadLine())
                {
                    case "1": Ver(historial); break;
                    case "2": AgregarItem(historial.Diagnosticos, "diagnostico"); break;
                    case "3": AgregarItem(historial.Tratamientos, "tratamiento"); break;
                    case "4": AgregarItem(historial.Observaciones, "observacion"); break;
                    case "5": Limpiar(historial); break;
                    case "6": return;
                    default: Console.WriteLine("Opcion invalida."); break;
                }
            }
        }

        private static void Ver(HistorialMedico h)
        {
            // Función local: imprime una sección del historial
            void ImprimirSeccion(string titulo, List<string> items, string sinItems)
            {
                Console.WriteLine($"\n  {titulo}:");
                if (!items.Any())
                    Console.WriteLine($"    ({sinItems})");
                else
                    // LINQ: Select proyecta cada item a su línea con prefijo; ForEach imprime
                    items.Select(x => $"    - {x}").ToList().ForEach(Console.WriteLine);
            }

            ImprimirSeccion("Diagnosticos",  h.Diagnosticos,  "ninguno");
            ImprimirSeccion("Tratamientos",  h.Tratamientos,  "ninguno");
            ImprimirSeccion("Observaciones", h.Observaciones, "ninguna");
        }

        private static void AgregarItem(List<string> lista, string tipo)
        {
            Console.WriteLine($"Ingrese {tipo}s (linea vacia para terminar):");

            // LINQ: generador perezoso + TakeWhile reemplaza el while con break
            var nuevos = EnumerarEntradas()
                .TakeWhile(linea => !string.IsNullOrWhiteSpace(linea))
                .ToList();

            // LINQ: Concat fusiona la lista existente con los nuevos; reemplaza AddRange en bucle
            var fusionados = lista.Concat(nuevos).ToList();
            lista.Clear();
            lista.AddRange(fusionados);

            Console.WriteLine($"{char.ToUpper(tipo[0]) + tipo[1..]} agregado(s).");
        }

        /// Generador perezoso de entradas de consola (yield return como IEnumerable funcional)
        private static IEnumerable<string> EnumerarEntradas()
        {
            while (true)
            {
                Console.Write("  > ");
                yield return Console.ReadLine() ?? "";
            }
        }

        private static void Limpiar(HistorialMedico h)
        {
            Console.Write("¿Limpiar todo el historial? (s/n): ");
            if (Console.ReadLine()?.ToLower() != "s") return;

            // LINQ: se itera sobre el arreglo de listas con ForEach para limpiar cada una
            new[] { h.Diagnosticos, h.Tratamientos, h.Observaciones }
                .ToList()
                .ForEach(lista => lista.Clear());

            Console.WriteLine("Historial limpiado.");
        }
    }
}
