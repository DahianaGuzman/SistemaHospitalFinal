using System;
using System.Linq;
using SistemaHospital.Aspectos;
using SistemaHospital.Interfaces;
using SistemaHospital.Models;

namespace AppConsole
{
    // ─────────────────────────────────────────────────────────────────────────
    //  UIDoctor — capa de presentación para gestión de doctores.
    //
    //  AOP: usa IDoctorServicio (proxy con interceptores) en lugar de
    //       DoctorRepository directamente, lo que activa los aspectos de
    //       Logging y Autenticación de licencia de forma transparente.
    //
    //  DIP: depende de la abstracción IDoctorServicio, no de la clase concreta.
    // ─────────────────────────────────────────────────────────────────────────
    internal static class UIDoctor
    {
        // El proxy teje los aspectos en tiempo de ejecución (POA)
        private static readonly IDoctorServicio _servicio = ProxyFactory.CrearDoctorServicio();

        // ── CRUD ─────────────────────────────────────────────────────────────

        private static void Crear()
        {
            var d = LeerDesdeConsola();
            try
            {
                // El interceptor de autenticación actúa ANTES de que este método
                // llegue a DoctorServicio.RegistrarDoctor — transparente para esta UI.
                _servicio.RegistrarDoctor(d);
                Console.WriteLine($"Doctor '{d.Nombre}' creado correctamente.");
            }
            catch (UnauthorizedAccessException ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"Error: {ex.Message}");
                Console.ResetColor();
            }
        }

        private static void Listar()
        {
            var doctores = _servicio.ObtenerTodos();
            if (!doctores.Any()) { Console.WriteLine("No hay doctores registrados."); return; }

            Console.WriteLine("\n--- Doctores ---");
            // LINQ: Select con índice proyecta cada doctor a su línea formateada
            doctores
                .Select((d, i) => $"[{i}] {d.Nombre} — ID: {d.Identificacion} | Esp: {d.Especialidad} | Lic: {d.LicenciaMedica}")
                .ToList()
                .ForEach(Console.WriteLine);
        }

        private static void Actualizar()
        {
            var doctores = _servicio.ObtenerTodos();
            Listar();
            if (!doctores.Any()) return;

            Console.Write("Indice a actualizar: ");
            if (!int.TryParse(Console.ReadLine(), out var idx) || idx < 0 || idx >= doctores.Count)
            { Console.WriteLine("Indice invalido."); return; }

            var d = doctores[idx];
            Console.WriteLine("Deje vacio para mantener el valor actual.");

            Console.Write($"Nombre ({d.Nombre}): ");
            var nombre = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(nombre)) d.Nombre = nombre;

            Console.Write($"Especialidad ({d.Especialidad}): ");
            var esp = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(esp)) d.Especialidad = esp;

            Console.Write($"Telefono ({d.Telefono}): ");
            if (int.TryParse(Console.ReadLine(), out var tel)) d.Telefono = tel;

            _servicio.Actualizar(doctores);
            Console.WriteLine("Doctor actualizado.");
        }

        private static void Eliminar()
        {
            var doctores = _servicio.ObtenerTodos();
            Listar();
            if (!doctores.Any()) return;

            Console.Write("Indice a eliminar: ");
            if (!int.TryParse(Console.ReadLine(), out var idx) || idx < 0 || idx >= doctores.Count)
            { Console.WriteLine("Indice invalido."); return; }

            var nombre = doctores[idx].Nombre;
            // LINQ: Where con índice filtra el elemento a eliminar; reemplaza RemoveAt
            _servicio.Eliminar(doctores.Where((_, i) => i != idx).ToList());
            Console.WriteLine($"Doctor '{nombre}' eliminado.");
        }

        public static Doctor? Seleccionar()
        {
            var doctores = _servicio.ObtenerTodos();

            if (doctores.Any())
            {
                Console.WriteLine("\nDoctores disponibles:");
                doctores
                    .Select((d, i) => $"[{i}] {d}")
                    .ToList()
                    .ForEach(Console.WriteLine);

                Console.Write("Indice ('n' = crear nuevo, 'c' = cancelar): ");
                var sel = Console.ReadLine();
                if (sel?.ToLower() == "c") return null;
                if (!string.IsNullOrWhiteSpace(sel) && sel.ToLower() != "n"
                    && int.TryParse(sel, out var idx) && idx >= 0 && idx < doctores.Count)
                    return doctores[idx];
            }

            var nuevo = LeerDesdeConsola();
            try
            {
                _servicio.RegistrarDoctor(nuevo);
            }
            catch (UnauthorizedAccessException ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"Error: {ex.Message}");
                Console.ResetColor();
                return null;
            }
            return nuevo;
        }

        public static Doctor LeerDesdeConsola()
        {
            Console.Write("Identificacion (numero): ");
            int id = int.TryParse(Console.ReadLine(), out var tmpId) ? tmpId : 0;

            Console.Write("Nombre: ");
            string nombre = Console.ReadLine() ?? "";

            Console.Write("Edad: ");
            int edad = int.TryParse(Console.ReadLine(), out var tmpE) ? tmpE : 0;

            Console.Write("Telefono: ");
            int tel = int.TryParse(Console.ReadLine(), out var tmpT) ? tmpT : 0;

            Console.Write("Especialidad: ");
            string esp = Console.ReadLine() ?? "";

            Console.Write("Licencia medica (numero): ");
            int lic = int.TryParse(Console.ReadLine(), out var tmpL) ? tmpL : 0;

            return new Doctor(id, nombre, edad, tel, esp, lic);
        }

        public static void Gestionar()
        {
            const string menu = """

                --- Gestion de Doctores ---
                1. Crear doctor
                2. Listar doctores
                3. Actualizar doctor
                4. Eliminar doctor
                5. Volver
                Opcion: 
                """;

            while (true)
            {
                Console.Write(menu);
                switch (Console.ReadLine())
                {
                    case "1": Crear();     break;
                    case "2": Listar();    break;
                    case "3": Actualizar(); break;
                    case "4": Eliminar();  break;
                    case "5": return;
                    default: Console.WriteLine("Opcion invalida."); break;
                }
            }
        }
    }
}
