using System.Collections.Generic;
using SistemaHospital.Models;

namespace SistemaHospital.Interfaces
{
    // ─────────────────────────────────────────────────────────────────────────
    //  ISP: la interfaz IDoctorServicio expone solo las operaciones relevantes
    //  para el servicio de doctores. Los proxies dinámicos de Castle requieren
    //  una interfaz para interceptar las llamadas a sus métodos.
    //  DIP: las capas superiores dependen de esta abstracción, no de la clase
    //  concreta DoctorServicio.
    // ─────────────────────────────────────────────────────────────────────────
    public interface IDoctorServicio
    {
        /// <summary>
        /// Registra un doctor después de validar su licencia médica.
        /// Este método es interceptado por el aspecto de autenticación.
        /// </summary>
        void RegistrarDoctor(Doctor doctor);

        List<Doctor> ObtenerTodos();
        void Actualizar(List<Doctor> doctores);
        void Eliminar(List<Doctor> doctores);
    }
}
