using System;
using SistemaHospital.Eventos;

namespace SistemaHospital.Eventos
{
    // ─────────────────────────────────────────────────────────────────────────
    //  Oyentes (Listeners / Subscribers) — Paradigma Orientado a Eventos
    //  Cada método es un Manejador de Evento (Event Handler): contiene la
    //  lógica de reacción cuando el Emisor (Paciente) dispara un evento.
    //  El Paciente no sabe quién escucha; simplemente dispara el evento.
    // ─────────────────────────────────────────────────────────────────────────

    public static class PacienteEventHandlers
    {
        /// <summary>
        /// Manejador del evento PacienteFallecido.
        /// Registra el suceso en consola (en producción iría a un log persistente).
        /// </summary>
        public static void OnPacienteFallecido(object? sender, PacienteFallecidoEventArgs e)
        {
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.WriteLine();
            Console.WriteLine("══════════════════════════════════════════════════");
            Console.WriteLine($"  [EVENTO] Paciente fallecido");
            Console.WriteLine($"  Paciente : {e.NombrePaciente} (ID: {e.IdPaciente})");
            Console.WriteLine($"  Causa    : {e.CausaFallecimiento}");
            Console.WriteLine($"  Fecha/Hr : {e.FechaHora:g}");
            Console.WriteLine("══════════════════════════════════════════════════");
            Console.ResetColor();
        }

        /// <summary>
        /// Manejador del evento PacienteDadoDeAlta.
        /// Notifica el alta satisfactoria con los detalles del egreso.
        /// </summary>
        public static void OnPacienteDadoDeAlta(object? sender, PacienteDadoDeAltaEventArgs e)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine();
            Console.WriteLine("══════════════════════════════════════════════════");
            Console.WriteLine($"  [EVENTO] Paciente dado de alta");
            Console.WriteLine($"  Paciente     : {e.NombrePaciente} (ID: {e.IdPaciente})");
            Console.WriteLine($"  Fecha Alta   : {e.FechaAlta:d}");
            Console.WriteLine($"  Observaciones: {(string.IsNullOrWhiteSpace(e.Observaciones) ? "Ninguna" : e.Observaciones)}");
            Console.WriteLine("══════════════════════════════════════════════════");
            Console.ResetColor();
        }
    }
}
