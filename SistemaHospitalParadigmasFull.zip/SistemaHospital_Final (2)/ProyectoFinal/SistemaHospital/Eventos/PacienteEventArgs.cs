using System;

namespace SistemaHospital.Eventos
{
    // ─────────────────────────────────────────────────────────────────────────
    //  Paradigma Orientado a Eventos
    //  EventArgs propios que transportan información relevante del dominio
    //  cuando el estado de un Paciente cambia de forma significativa.
    // ─────────────────────────────────────────────────────────────────────────

    /// <summary>
    /// Datos que acompañan al evento cuando un paciente fallece.
    /// Inmutable por diseño: los datos de un fallecimiento no deben mutarse.
    /// </summary>
    public class PacienteFallecidoEventArgs : EventArgs
    {
        public int IdPaciente { get; }
        public string NombrePaciente { get; }
        public string CausaFallecimiento { get; }
        public DateTime FechaHora { get; }

        public PacienteFallecidoEventArgs(
            int idPaciente,
            string nombrePaciente,
            string causaFallecimiento,
            DateTime fechaHora)
        {
            IdPaciente = idPaciente;
            NombrePaciente = nombrePaciente;
            CausaFallecimiento = causaFallecimiento;
            FechaHora = fechaHora;
        }
    }

    /// <summary>
    /// Datos que acompañan al evento cuando un paciente es dado de alta.
    /// Inmutable por diseño: refuerza la Programación Funcional.
    /// </summary>
    public class PacienteDadoDeAltaEventArgs : EventArgs
    {
        public int IdPaciente { get; }
        public string NombrePaciente { get; }
        public DateTime FechaAlta { get; }
        public string Observaciones { get; }

        public PacienteDadoDeAltaEventArgs(
            int idPaciente,
            string nombrePaciente,
            DateTime fechaAlta,
            string observaciones)
        {
            IdPaciente = idPaciente;
            NombrePaciente = nombrePaciente;
            FechaAlta = fechaAlta;
            Observaciones = observaciones;
        }
    }
}