using SistemaHospital.Models;

namespace SistemaHospital.Repositories
{
    public class DoctorRepository : CsvRepository<Doctor>
    {
        public DoctorRepository() : base("doctores.csv") { }
    }
}
