using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using CsvHelper;
using SistemaHospital.Models;

namespace SistemaHospital.Repositories
{
    /// <summary>
    /// El historial no puede guardarse directo en CSV porque tiene List<string> internas.
    /// Usamos un DTO (PacienteDto) que serializa todo a campos planos, y lo convertimos
    /// a Paciente al cargar. Así el CSV sigue siendo simple y legible.
    /// </summary>
    public class PacienteHistorialRepository
    {
        private const string FilePath = "pacientes.csv";

        private class PacienteDto
        {
            public int    Identificacion { get; set; }
            public string Nombre         { get; set; } = string.Empty;
            public int    Edad           { get; set; }
            public int    Telefono       { get; set; }
            public string FechaIngreso   { get; set; } = string.Empty;
            public string Diagnosticos   { get; set; } = string.Empty;
            public string Tratamientos   { get; set; } = string.Empty;
            public string Observaciones  { get; set; } = string.Empty;
        }

        public List<Paciente> CargarTodos()
        {
            if (!File.Exists(FilePath)) return new List<Paciente>();

            using var reader = new StreamReader(FilePath);
            using var csv    = new CsvReader(reader, CultureInfo.InvariantCulture);

            // LINQ: Select proyecta cada DTO a un Paciente completo con su Historial
            return csv.GetRecords<PacienteDto>()
                .Select(dto => new Paciente(
                    dto.Identificacion,
                    dto.Nombre,
                    dto.Edad,
                    dto.Telefono,
                    DateTime.TryParse(dto.FechaIngreso, out var fi) ? fi : DateTime.Now
                )
                {
                    Historial = new HistorialMedico(
                        SplitLista(dto.Diagnosticos),
                        SplitLista(dto.Tratamientos),
                        SplitLista(dto.Observaciones)
                    )
                })
                .ToList();
        }

        public void GuardarTodos(List<Paciente> pacientes)
        {
            // LINQ: Select proyecta cada Paciente al DTO plano para serializar en CSV
            var dtos = pacientes
                .Select(p => new PacienteDto
                {
                    Identificacion = p.Identificacion,
                    Nombre         = p.Nombre,
                    Edad           = p.Edad,
                    Telefono       = p.Telefono,
                    FechaIngreso   = p.FechaIngreso.ToString("o"),
                    Diagnosticos   = string.Join("|", p.Historial.Diagnosticos),
                    Tratamientos   = string.Join("|", p.Historial.Tratamientos),
                    Observaciones  = string.Join("|", p.Historial.Observaciones)
                })
                .ToList();

            using var writer = new StreamWriter(FilePath);
            using var csvW   = new CsvWriter(writer, CultureInfo.InvariantCulture);
            csvW.WriteRecords(dtos);
        }

        // Función pura (PF): misma entrada → misma salida, sin efectos secundarios
        private static List<string> SplitLista(string valor) =>
            string.IsNullOrWhiteSpace(valor)
                ? new List<string>()
                : valor.Split('|').Where(s => !string.IsNullOrEmpty(s)).ToList();
    }
}
