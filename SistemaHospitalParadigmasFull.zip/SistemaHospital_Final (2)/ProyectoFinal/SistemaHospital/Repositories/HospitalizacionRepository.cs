using System.Collections.Generic;
using System.Linq;
using SistemaHospital.Interfaces;
using SistemaHospital.Models;

namespace SistemaHospital.Repositories
{
    public class HospitalizacionRepository : CsvRepository<Hospitalizacion>, IAsignacionHabitacion
    {
        private const int TotalHabitaciones = 10;

        public HospitalizacionRepository() : base("hospitalizaciones.csv") { }

        public int ObtenerHabitacionDisponible()
        {
            // LINQ: obtiene el conjunto de habitaciones ocupadas activas
            var ocupadas = CargarTodos()
                .Where(h => !h.FechaAlta.HasValue)
                .Select(h => h.NumeroHabitacion)
                .ToHashSet();

            // LINQ: busca el primer número libre en el rango 1..TotalHabitaciones
            return Enumerable.Range(1, TotalHabitaciones)
                .FirstOrDefault(n => !ocupadas.Contains(n), -1);
        }

        public bool HabitacionDisponible(int numeroHabitacion) =>
            // LINQ: verifica que ninguna hospitalización activa use esa habitación
            !CargarTodos()
                .Where(h => !h.FechaAlta.HasValue)
                .Any(h => h.NumeroHabitacion == numeroHabitacion);
    }
}
