using SistemaHospital.Models;

namespace SistemaHospital.Repositories
{
    public class CitaRepository : CsvRepository<Cita>
    {
        public CitaRepository() : base("citas.csv") { }
    }
}
