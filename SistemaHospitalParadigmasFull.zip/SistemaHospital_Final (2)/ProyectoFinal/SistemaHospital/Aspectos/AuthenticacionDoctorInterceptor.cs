using System;
using Castle.DynamicProxy;

namespace SistemaHospital.Aspectos
{
    // ─────────────────────────────────────────────────────────────────────────
    //  Paradigma Orientado a Aspectos (POA / AOP)
    //
    //  AuthenticacionDoctorInterceptor — Aspecto de Autenticación
    //
    //  Inquietud transversal: validar autenticación antes de ejecutar métodos
    //  del servicio de doctores sin contaminar la lógica de negocio.
    //
    //  Este es el primer interceptor requerido por el proyecto final.
    // ─────────────────────────────────────────────────────────────────────────
    public class AuthenticacionDoctorInterceptor : IInterceptor
    {
        public void Intercept(IInvocation invocation)
        {
            // BEFORE: validación de autenticación
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"[AUTH] Verificando autenticación para: {invocation.Method.Name}");
            Console.ResetColor();

            // Ejecuta el método real
            invocation.Proceed();

            // AFTER: lógica después de ejecutar el método real
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"[AUTH] Autenticación completada para: {invocation.Method.Name}");
            Console.ResetColor();
        }
    }
}
