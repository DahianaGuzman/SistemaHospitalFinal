using System;
using System.Linq;
using Castle.DynamicProxy;

namespace SistemaHospital.Aspectos
{
    // ─────────────────────────────────────────────────────────────────────────
    //  Paradigma Orientado a Aspectos (POA / AOP)
    //
    //  LoggingInterceptor — Aspecto de Logging / Auditoría
    //
    //  Inquietud transversal: registrar la entrada y salida de los métodos
    //  del servicio de doctores sin contaminar la lógica de negocio.
    //
    //  Este es el segundo interceptor requerido por el proyecto final.
    // ─────────────────────────────────────────────────────────────────────────
    public class LoggingInterceptor : IInterceptor
    {
        public void Intercept(IInvocation invocation)
        {
            // BEFORE: lógica antes de ejecutar el método real
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine($"[LOG] → Llamando a: {invocation.Method.Name}");
            if (invocation.Arguments.Length > 0)
                Console.WriteLine($"[LOG]   Argumentos: {string.Join(", ", invocation.Arguments.Select(a => a?.ToString() ?? "null"))}");
            Console.ResetColor();

            // Ejecuta el método real
            invocation.Proceed();

            // AFTER: lógica después de ejecutar el método real
            Console.ForegroundColor = ConsoleColor.DarkGray;
            var retorno = invocation.ReturnValue != null ? invocation.ReturnValue.ToString() : "void";
            Console.WriteLine($"[LOG] ← {invocation.Method.Name} completado. Retorno: {retorno}");
            Console.ResetColor();
        }
    }
}
