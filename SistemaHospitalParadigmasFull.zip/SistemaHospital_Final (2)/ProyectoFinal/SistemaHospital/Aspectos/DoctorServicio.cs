using System.Collections.Generic;
using System.Linq;
using SistemaHospital.Interfaces;
using SistemaHospital.Models;
using SistemaHospital.Repositories;

namespace SistemaHospital.Aspectos
{
    // ─────────────────────────────────────────────────────────────────────────
    //  DoctorServicio — implementación concreta de IDoctorServicio.
    //
    //  Esta clase NO sabe nada de autenticación ni logging.
    //  Esas inquietudes transversales son responsabilidad de los interceptores.
    //  El proxy las "teje" en tiempo de ejecución (POA).
    //
    //  SRP: su única responsabilidad es la lógica de gestión de doctores.
    //  DIP: depende de DoctorRepository (que hereda de CsvRepository<T>).
    // ─────────────────────────────────────────────────────────────────────────
    public class DoctorServicio : IDoctorServicio
    {
        private readonly DoctorRepository _repo;

        public DoctorServicio(DoctorRepository repo)
        {
            _repo = repo;
        }

        public void RegistrarDoctor(Doctor doctor)
        {
            // LINQ: Append + ToList reemplaza .Add() — inmutabilidad funcional
            _repo.GuardarTodos(_repo.CargarTodos().Append(doctor).ToList());
        }

        public List<Doctor> ObtenerTodos() => _repo.CargarTodos();

        public void Actualizar(List<Doctor> doctores) => _repo.GuardarTodos(doctores);

        public void Eliminar(List<Doctor> doctores) => _repo.GuardarTodos(doctores);
    }
}
