using Castle.DynamicProxy;
using SistemaHospital.Interfaces;
using SistemaHospital.Repositories;

namespace SistemaHospital.Aspectos
{
    // ─────────────────────────────────────────────────────────────────────────
    //  ProxyFactory — fábrica de proxies dinámicos (Paradigma de Aspectos)
    //
    //  SRP: su única razón de cambiar es la composición del proxy.
    //  OCP: para agregar un nuevo aspecto solo se añade un interceptor aquí,
    //       sin modificar DoctorServicio ni ninguna otra clase.
    // ─────────────────────────────────────────────────────────────────────────
    public static class ProxyFactory
    {
        private static readonly ProxyGenerator _generator = new();

        /// <summary>
        /// Crea un proxy dinámico de IDoctorServicio con los aspectos de
        /// Logging y Autenticación tejidos en tiempo de ejecución.
        /// El orden de los interceptores define la cadena de ejecución.
        /// </summary>
        public static IDoctorServicio CrearDoctorServicio()
        {
            var repo     = new DoctorRepository();
            var servicio = new DoctorServicio(repo);

            // Interceptores en orden: Logging → Autenticación → método real
            return _generator.CreateInterfaceProxyWithTarget<IDoctorServicio>(
                servicio,
                new LoggingInterceptor(),
                new AuthenticacionDoctorInterceptor()
            );
        }
    }
}
