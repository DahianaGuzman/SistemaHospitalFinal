using System;
using SistemaHospital.Eventos;

namespace SistemaHospital.Models
{
    // ──────────────────────────────────────────────
    //  Paciente — lleva su HistorialMedico consigo.
    //  Paradigma de Eventos: dispara PacienteFallecido
    //  y PacienteDadoDeAlta cuando su estado cambia.
    // ──────────────────────────────────────────────
    public class Paciente : Persona
    {
        public DateTime FechaIngreso { get; set; }
        public HistorialMedico Historial { get; set; } = new();

        // ── Eventos (Paradigma Orientado a Eventos) ──────────────────────────
        /// Disparado cuando el paciente fallece en el hospital.
        public event EventHandler<PacienteFallecidoEventArgs>? Fallecido;

        /// Disparado cuando el paciente es dado de alta exitosamente.
        public event EventHandler<PacienteDadoDeAltaEventArgs>? DadoDeAlta;

        // Constructor vacío requerido por CsvHelper
        public Paciente() : base(string.Empty, 0, 0, 0) { }

        public Paciente(int identificacion, string nombre, int edad, int telefono, DateTime fechaIngreso)
            : base(nombre, identificacion, edad, telefono)
        {
            FechaIngreso = fechaIngreso;
            Historial = new HistorialMedico();
        }

        // ── Métodos que disparan eventos ─────────────────────────────────────

        /// Registra el fallecimiento del paciente y dispara el evento correspondiente.
        public void RegistrarFallecimiento(string causa)
        {
            // El Emisor (Paciente) dispara el evento; los Oyentes reaccionan.
            Fallecido?.Invoke(this, new PacienteFallecidoEventArgs(Identificacion, Nombre, causa, DateTime.Now));
        }

        /// Registra el alta del paciente y dispara el evento correspondiente.
        public void RegistrarAlta(DateTime fechaAlta, string observaciones = "")
        {
            // El Emisor (Paciente) dispara el evento; los Oyentes reaccionan.
            DadoDeAlta?.Invoke(this, new PacienteDadoDeAltaEventArgs(Identificacion, Nombre, fechaAlta, observaciones));
        }

        public override string ToString() => $"{Nombre} (ID: {Identificacion})";
    }
}
