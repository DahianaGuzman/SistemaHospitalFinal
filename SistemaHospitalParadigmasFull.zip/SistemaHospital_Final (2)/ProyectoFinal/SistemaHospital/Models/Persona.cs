using System;

namespace SistemaHospital.Models
{
    public class Persona
    {
        public string Nombre { get; set; }
        public int Identificacion { get; set; }
        public int Edad { get; set; }
        public int Telefono { get; set; }

        public Persona(string nombre, int identificacion, int edad, int telefono)
        {
            Nombre = nombre;
            Identificacion = identificacion;
            Edad = edad;
            Telefono = telefono;
        }
    }
}
