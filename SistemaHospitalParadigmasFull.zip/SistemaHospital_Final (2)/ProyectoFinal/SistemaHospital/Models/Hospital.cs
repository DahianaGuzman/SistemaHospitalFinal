using System.Collections.Generic;
using System.Linq;

namespace SistemaHospital.Models
{
    public class Hospital
    {
        public List<Doctor> Doctores { get; set; }
        public List<Habitacion> Habitaciones { get; set; }
        public List<Paciente> Pacientes { get; set; }
        public List<Hospitalizacion> Hospitalizaciones { get; set; }

        public Hospital(int cantidadHabitaciones)
        {
            // LINQ: Enumerable.Range + Select reemplazan el for tradicional
            Habitaciones      = Enumerable.Range(1, cantidadHabitaciones).Select(i => new Habitacion(i)).ToList();
            Doctores          = new List<Doctor>();
            Pacientes         = new List<Paciente>();
            Hospitalizaciones = new List<Hospitalizacion>();
        }

        // LINQ: Append + ToList reemplazan .Add()
        public void AgregarDoctor(Doctor doctor) =>
            Doctores = Doctores.Append(doctor).ToList();

        public void AgregarPaciente(Paciente paciente) =>
            Pacientes = Pacientes.Append(paciente).ToList();
    }
}
