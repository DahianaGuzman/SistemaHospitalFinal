namespace SistemaHospital.Models
{
    public class Doctor : Persona
    {
        public string Especialidad { get; set; } = string.Empty;
        public int LicenciaMedica { get; set; }

        // Constructor vacío requerido por CsvHelper
        public Doctor() : base(string.Empty, 0, 0, 0) { }

        public Doctor(int identificacion, string nombre, int edad, int telefono, string especialidad, int licenciaMedica)
            : base(nombre, identificacion, edad, telefono)
        {
            Especialidad = especialidad;
            LicenciaMedica = licenciaMedica;
        }

        public override string ToString() => $"Dr. {Nombre} — {Especialidad} (Lic: {LicenciaMedica})";
    }
}
